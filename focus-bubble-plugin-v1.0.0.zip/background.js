// Background service worker for website blocking

// Import shared utility functions and services
importScripts('utils.js');
importScripts('services/storage-service.js');
importScripts('services/blocking-service.js');
importScripts('services/message-handler.js');
importScripts('services/alarm-handler.js');
importScripts('services/declarative-net-request-service.js');

// ============================================
// Initialization
// ============================================

// Initialize storage on install
chrome.runtime.onInstalled.addListener(async () => {
  await StorageService.initializeSettings();
  await DeclarativeNetRequestService.restoreBlockingRules();
});

// Listen for tab updates to check if domain should be blocked
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    try {
      await BlockingService.checkAndBlockDomain(tab.url, tabId);
  } catch (error) {
      console.error('Error checking and blocking domain:', error);
      // Don't throw - allow tab to load normally if blocking fails
    }
  }
});

// Initialize alarm handler
AlarmHandler.init();

// Initialize message handler
MessageHandler.init();
