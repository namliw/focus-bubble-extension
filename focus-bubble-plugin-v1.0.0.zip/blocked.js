// Blocked page script

// Get URL parameters
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    domain: params.get('domain'),
    original: params.get('original')
  };
}

// Unblock domain with reason
async function unblockDomain(domain, reason) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'unblockDomain', domain: domain, reason: reason },
      (response) => {
        resolve(response?.success || false);
      }
    );
  });
}

// Get blocked sites info
async function getBlockedSites() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getBlockedSites' },
      (response) => {
        resolve(response?.blockedSites || {});
      }
    );
  });
}

// Get settings
async function getSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getSettings' },
      (response) => {
        resolve(response?.settings || {});
      }
    );
  });
}

// Format time remaining
function formatTimeRemaining(expiresAt) {
  const now = Date.now();
  const remaining = expiresAt - now;
  if (remaining <= 0) return 'Shield removed';
  
  const minutes = Math.floor(remaining / 60000);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m remaining`;
  }
  return `${minutes}m remaining`;
}

// Check if within work hours
function isWithinWorkHours(startTime, endTime) {
  const now = new Date();
  const currentHours = now.getHours();
  const currentMinutes = now.getMinutes();
  const currentTotalMinutes = currentHours * 60 + currentMinutes;
  
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);
  const startTotalMinutes = startHours * 60 + startMinutes;
  const endTotalMinutes = endHours * 60 + endMinutes;
  
  if (startTotalMinutes <= endTotalMinutes) {
    return currentTotalMinutes >= startTotalMinutes && currentTotalMinutes < endTotalMinutes;
  } else {
    return currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes;
  }
}

// Initialize blocked page
async function initBlockedPage() {
  const params = getUrlParams();
  const domain = params.domain;
  const originalUrl = params.original;
  
  if (!domain) {
    document.getElementById('blockedDomain').textContent = 'Unknown space';
    return;
  }
  
  document.getElementById('blockedDomain').textContent = domain;
  
  // Get protection info
  const blockedSites = await getBlockedSites();
  const blockInfo = blockedSites[domain];
  
  if (blockInfo) {
    const blockInfoDiv = document.getElementById('blockInfo');
    const infoText = document.getElementById('infoText');
    
    let infoMessage = '';
    switch (blockInfo.mode) {
      case 'full':
        infoMessage = 'Focus mode: Deep Focus';
        break;
      case 'workHours':
        const settings = await getSettings();
        const withinHours = isWithinWorkHours(
          settings.workHoursStart || '09:00',
          settings.workHoursEnd || '17:00'
        );
        infoMessage = `Focus mode: Work Hours (${settings.workHoursStart || '09:00'} - ${settings.workHoursEnd || '17:00'})`;
        if (!withinHours) {
          infoMessage += ' - Currently outside work hours, but shield remains active';
        }
        break;
      case 'next1h':
        if (blockInfo.expiresAt) {
          const remaining = formatTimeRemaining(blockInfo.expiresAt);
          infoMessage = `Focus mode: Brief Pause - ${remaining}`;
        } else {
          infoMessage = 'Focus mode: Brief Pause';
        }
        break;
    }
    
    infoText.textContent = infoMessage;
    blockInfoDiv.style.display = 'block';
  }
  
  // Set up reason textarea and unblock button
  const reasonTextarea = document.getElementById('unblockReason');
  const unblockButton = document.getElementById('unblockButton');
  
  // Enable/disable unblock button based on reason input
  reasonTextarea.addEventListener('input', () => {
    const reason = reasonTextarea.value.trim();
    unblockButton.disabled = reason.length === 0;
  });
  
  // Set up unblock button
  unblockButton.addEventListener('click', async () => {
    const reason = reasonTextarea.value.trim();
    
    if (reason.length === 0) {
      return; // Should not happen due to disabled state, but safety check
    }
    
    const success = await unblockDomain(domain, reason);
    
    if (success && originalUrl) {
      // Silently redirect back to original URL
      window.location.href = originalUrl;
    } else if (success) {
      // If no original URL, redirect to a safe page
      window.location.href = 'https://www.google.com';
    }
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initBlockedPage);
} else {
  initBlockedPage();
}

