// Options page script

// Get blocked sites
async function getBlockedSites() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getBlockedSites' },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error getting blocked sites:', chrome.runtime.lastError.message);
          resolve({});
          return;
        }
        resolve(response?.blockedSites || {});
      }
    );
  });
}

// Get settings
async function getSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getSettings' },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error getting settings:', chrome.runtime.lastError.message);
          resolve({});
          return;
        }
        resolve(response?.settings || {});
      }
    );
  });
}

// Update settings
async function updateSettings(settings) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'updateSettings', settings: settings },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error updating settings:', chrome.runtime.lastError.message);
          resolve(false);
          return;
        }
        resolve(response?.success || false);
      }
    );
  });
}

// Unblock domain
async function unblockDomain(domain) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'unblockDomain', domain: domain, reason: '' },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error unblocking domain:', chrome.runtime.lastError.message);
          resolve(false);
          return;
        }
        resolve(response?.success || false);
      }
    );
  });
}

// Get unblock history
async function getUnblockHistory() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getUnblockHistory' },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error getting unblock history:', chrome.runtime.lastError.message);
          resolve([]);
          return;
        }
        resolve(response?.history || []);
      }
    );
  });
}

// Note: formatBlockingMode is imported from utils.js

// Render blocked sites list
async function renderBlockedSites() {
  const blockedSites = await getBlockedSites();
  const listContainer = document.getElementById('blockedSitesList');
  const emptyMessage = document.getElementById('emptyMessage');
  
  const domains = Object.keys(blockedSites);
  
  if (domains.length === 0) {
    emptyMessage.style.display = 'block';
    listContainer.innerHTML = '<p class="empty-message" id="emptyMessage">No websites blocked yet.</p>';
    return;
  }
  
  emptyMessage.style.display = 'none';
  
  listContainer.innerHTML = '';
  
  for (const [domain, blockInfo] of Object.entries(blockedSites)) {
    const siteItem = document.createElement('div');
    siteItem.className = 'site-item';
    
    const modeText = formatBlockingMode(blockInfo.mode, blockInfo);
    const modeClass = blockInfo.mode === 'full' ? 'full' : 
                     blockInfo.mode === 'workHours' ? 'workHours' : 'next1h';
    
    // Create elements safely using DOM manipulation to prevent XSS
    const siteInfo = document.createElement('div');
    siteInfo.className = 'site-info';
    
    const siteDomain = document.createElement('div');
    siteDomain.className = 'site-domain';
    siteDomain.textContent = domain; // Safe - uses textContent instead of innerHTML
    
    const siteMode = document.createElement('div');
    siteMode.className = 'site-mode';
    siteMode.textContent = modeText + ' '; // Safe
    
    const siteModeBadge = document.createElement('span');
    siteModeBadge.className = `site-mode-badge ${modeClass}`;
    siteModeBadge.textContent = blockInfo.mode; // Safe
    siteMode.appendChild(siteModeBadge);
    
    siteInfo.appendChild(siteDomain);
    siteInfo.appendChild(siteMode);
    
    const siteActions = document.createElement('div');
    siteActions.className = 'site-actions';
    
    const visitButton = document.createElement('button');
    visitButton.className = 'btn btn-visit';
    visitButton.textContent = 'Dive In';
    visitButton.setAttribute('data-domain', domain); // Safe - setAttribute escapes values
    
    siteActions.appendChild(visitButton);
    
    siteItem.appendChild(siteInfo);
    siteItem.appendChild(siteActions);
    
    listContainer.appendChild(siteItem);
    
    // Add event listener for visit button
    visitButton.addEventListener('click', async () => {
      // Validate domain format before constructing URL
      if (!/^[a-zA-Z0-9.-]+$/.test(domain)) {
        console.error('Invalid domain format:', domain);
        return;
      }
      
      // Navigate to the blocked website (will show blocked page)
      const url = `https://${domain}`;
      try {
        // Try to open in current window, or create new tab
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0] && tabs[0].id) {
          await chrome.tabs.update(tabs[0].id, { url: url });
        } else {
          await chrome.tabs.create({ url: url });
        }
        // Close the options page
        window.close();
      } catch (error) {
        console.error('Error navigating to site:', error);
        // Fallback: open in new tab
        await chrome.tabs.create({ url: url });
        window.close();
      }
    });
  }
}

// Note: formatTimestamp and formatDuration are imported from utils.js

// Render unblock history
async function renderUnblockHistory() {
  try {
    const history = await getUnblockHistory();
    const listContainer = document.getElementById('unblockHistoryList');
    const emptyMessage = document.getElementById('emptyHistoryMessage');
    
    console.log('Unblock history retrieved:', history);
    
    // Sort by timestamp (newest first)
    history.sort((a, b) => b.timestamp - a.timestamp);
    
    if (history.length === 0) {
      emptyMessage.style.display = 'block';
      listContainer.innerHTML = '<p class="empty-message" id="emptyHistoryMessage">No unblock history yet.</p>';
      return;
    }
    
    emptyMessage.style.display = 'none';
    listContainer.innerHTML = '';
    
    for (const entry of history) {
      if (!entry || !entry.domain || !entry.reason) {
        console.warn('Invalid history entry:', entry);
        continue;
      }
      
      const historyItem = document.createElement('div');
      historyItem.className = 'history-item';
      
      const modeClass = entry.mode === 'full' ? 'full' : 
                       entry.mode === 'workHours' ? 'workHours' : 'next1h';
      const modeText = entry.mode === 'full' ? 'Deep Focus' : 
                      entry.mode === 'workHours' ? 'Work Hours' : 'Brief Pause';
      
      // Create elements safely using DOM manipulation to prevent XSS
      const historyHeader = document.createElement('div');
      historyHeader.className = 'history-header';
      
      const headerLeft = document.createElement('div');
      
      const historyDomain = document.createElement('span');
      historyDomain.className = 'history-domain';
      historyDomain.textContent = entry.domain; // Safe
      
      const historyModeBadge = document.createElement('span');
      historyModeBadge.className = `history-mode-badge ${modeClass}`;
      historyModeBadge.textContent = modeText; // Safe
      
      headerLeft.appendChild(historyDomain);
      headerLeft.appendChild(historyModeBadge);
      
      const historyMeta = document.createElement('div');
      historyMeta.className = 'history-meta';
      
      const historyTimestamp = document.createElement('div');
      historyTimestamp.className = 'history-timestamp';
      historyTimestamp.textContent = formatTimestamp(entry.timestamp); // Safe
      
      const historyDuration = document.createElement('div');
      historyDuration.className = 'history-duration';
      historyDuration.textContent = 'Shielded for ' + formatDuration(entry.blockDuration); // Safe
      
      historyMeta.appendChild(historyTimestamp);
      historyMeta.appendChild(historyDuration);
      
      historyHeader.appendChild(headerLeft);
      historyHeader.appendChild(historyMeta);
      
      const historyReason = document.createElement('div');
      historyReason.className = 'history-reason';
      historyReason.textContent = entry.reason; // Safe - textContent auto-escapes
      
      historyItem.appendChild(historyHeader);
      historyItem.appendChild(historyReason);
      
      listContainer.appendChild(historyItem);
    }
  } catch (error) {
    console.error('Error rendering unblock history:', error);
  }
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Initialize options page
async function initOptionsPage() {
  // Load and display blocked sites
  await renderBlockedSites();
  
  // Load and display unblock history
  await renderUnblockHistory();
  
  // Listen for storage changes to refresh history
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.unblockHistory) {
      console.log('Unblock history changed, refreshing...');
      renderUnblockHistory();
    }
  });
  
  // Load work hours settings
  const settings = await getSettings();
  if (settings.workHoursStart) {
    document.getElementById('workHoursStart').value = settings.workHoursStart;
  }
  if (settings.workHoursEnd) {
    document.getElementById('workHoursEnd').value = settings.workHoursEnd;
  }
  
  // Set up save work hours button
  document.getElementById('saveWorkHours').addEventListener('click', async () => {
    const startTime = document.getElementById('workHoursStart').value;
    const endTime = document.getElementById('workHoursEnd').value;
    
    if (!startTime || !endTime) {
      alert('Please enter both start and end times.');
      return;
    }
    
    // Validate time format
    const timeRegex = /^\d{1,2}:\d{2}$/;
    if (!timeRegex.test(startTime) || !timeRegex.test(endTime)) {
      alert('Invalid time format. Please use HH:MM format.');
      return;
    }
    
    // Validate time ranges
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    
    if (startHours < 0 || startHours > 23 || startMinutes < 0 || startMinutes > 59) {
      alert('Start time must be between 00:00 and 23:59.');
      return;
    }
    
    if (endHours < 0 || endHours > 23 || endMinutes < 0 || endMinutes > 59) {
      alert('End time must be between 00:00 and 23:59.');
      return;
    }
    
    const newSettings = {
      ...settings,
      workHoursStart: startTime,
      workHoursEnd: endTime
    };
    
    const success = await updateSettings(newSettings);
    
    if (success) {
      // Show success message
      const successMsg = document.createElement('div');
      successMsg.className = 'success-message show';
      successMsg.textContent = 'Work hours saved successfully!';
      document.querySelector('.work-hours-config').appendChild(successMsg);
      
      setTimeout(() => {
        successMsg.remove();
      }, 3000);
    } else {
      alert('Failed to save work hours. Please try again.');
    }
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initOptionsPage);
} else {
  initOptionsPage();
}

