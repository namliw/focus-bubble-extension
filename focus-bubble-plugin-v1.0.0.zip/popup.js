// Popup script for extension icon dropdown
// Note: extractDomain and normalizeDomain are imported from utils.js

// Get current tab URL
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Check if domain is blocked
async function isDomainBlocked(domain) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'isDomainBlocked', domain: domain },
      (response) => {
        resolve(response?.blocked || false);
      }
    );
  });
}

// Block domain
async function blockDomain(domain, mode) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'blockDomain', domain: domain, mode: mode },
      (response) => {
        resolve(response?.success || false);
      }
    );
  });
}

// Initialize popup
async function initPopup() {
  try {
    const tab = await getCurrentTab();
    if (!tab || !tab.url) {
      document.getElementById('currentDomain').textContent = 'No space found';
      return;
    }
    
    const domain = extractDomain(tab.url);
    if (!domain) {
      document.getElementById('currentDomain').textContent = 'Unable to identify space';
      return;
    }
    
    const normalizedDomain = normalizeDomain(domain);
    document.getElementById('currentDomain').textContent = normalizedDomain;
    document.getElementById('blockedDomain').textContent = normalizedDomain;
    
    // Check if domain is blocked
    const blocked = await isDomainBlocked(normalizedDomain);
    
    if (blocked) {
      // Show blocked view
      document.getElementById('notBlockedView').style.display = 'none';
      document.getElementById('blockedView').style.display = 'block';
    } else {
      // Show not blocked view
      document.getElementById('notBlockedView').style.display = 'block';
      document.getElementById('blockedView').style.display = 'none';
    }
    
    // Set up settings link
    document.getElementById('settingsLink').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
    
    document.getElementById('settingsLinkBlocked').addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
    
    // Set up block button
    document.getElementById('blockButton').addEventListener('click', async () => {
      const mode = document.getElementById('blockMode').value;
      const success = await blockDomain(normalizedDomain, mode);
      
      if (success) {
        // Update UI to show blocked view
        document.getElementById('notBlockedView').style.display = 'none';
        document.getElementById('blockedView').style.display = 'block';
        
        // Reload the tab to show the blocked page
        if (tab.id) {
          try {
            await chrome.tabs.reload(tab.id);
            // Close the popup after a short delay to allow reload to start
            window.close();
          } catch (error) {
            console.error('Error reloading tab:', error);
            // If reload fails, try navigating to the blocked page
            const blockedUrl = chrome.runtime.getURL('blocked.html') + '?domain=' + encodeURIComponent(normalizedDomain) + '&original=' + encodeURIComponent(tab.url);
            await chrome.tabs.update(tab.id, { url: blockedUrl });
          }
        }
      }
    });
    
  } catch (error) {
    console.error('Error initializing popup:', error);
    document.getElementById('currentDomain').textContent = 'Loading...';
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup);
} else {
  initPopup();
}

