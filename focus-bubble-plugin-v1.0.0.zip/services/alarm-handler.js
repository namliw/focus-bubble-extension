/**
 * Alarm Handler Service
 * Handles chrome.alarms.onAlarm events
 */

const AlarmHandler = {
  /**
   * Initialize alarm listeners
   */
  init() {
    chrome.alarms.onAlarm.addListener(async (alarm) => {
      if (alarm.name.startsWith('unblock_')) {
        const domain = alarm.name.replace('unblock_', '');
        await BlockingService.unblockDomain(domain, '');
      }
      
      // Check all blocks periodically for work hours
      if (alarm.name === 'checkWorkHours') {
        await this.checkAllWorkHoursBlocks();
      }
    });
  },

  /**
   * Check all work hours blocks and redirect tabs if needed
   * @returns {Promise<void>}
   */
  async checkAllWorkHoursBlocks() {
    try {
      const blockedSites = await StorageService.getBlockedSites();
      const settings = await StorageService.getSettings();
      const tabs = await safeChromeCall(
        () => chrome.tabs.query({}),
        'query tabs',
        []
      );
      
      for (const [domain, blockInfo] of Object.entries(blockedSites)) {
        if (blockInfo.mode === 'workHours') {
          const shouldBlock = isWithinWorkHours(
            settings.workHoursStart || StorageService.DEFAULT_SETTINGS.workHoursStart,
            settings.workHoursEnd || StorageService.DEFAULT_SETTINGS.workHoursEnd
          );
          
          // Check all tabs and redirect if needed
          for (const tab of tabs) {
            if (tab.url) {
              const tabDomain = normalizeDomain(extractDomain(tab.url));
              if (tabDomain === domain && shouldBlock) {
                const blockedUrl = chrome.runtime.getURL('blocked.html') + '?domain=' + encodeURIComponent(domain) + '&original=' + encodeURIComponent(tab.url);
                await safeChromeCall(
                  () => chrome.tabs.update(tab.id, { url: blockedUrl }),
                  `update tab ${tab.id}`
                );
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('Error checking work hours blocks:', error);
    }
  }
};

// Helper function for safe Chrome calls
async function safeChromeCall(apiCall, operation, defaultValue = null) {
  try {
    return await withRetry(apiCall, 3, 100);
  } catch (error) {
    console.error(`Error in ${operation}:`, error);
    return defaultValue;
  }
}

async function withRetry(fn, maxAttempts = 3, baseDelay = 100) {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts - 1) {
        throw error;
      }
      const delay = baseDelay * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

// Export for service worker
if (typeof module !== 'undefined' && module.exports) {
  module.exports = AlarmHandler;
}

// Make available globally
if (typeof globalThis !== 'undefined') {
  globalThis.AlarmHandler = AlarmHandler;
}

