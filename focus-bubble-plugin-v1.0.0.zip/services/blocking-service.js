/**
 * Blocking Service
 * Handles domain blocking and unblocking logic
 */

const BlockingService = {
  /**
   * Block a domain
   * @param {string} domain - Domain to block
   * @param {string} mode - Blocking mode ('full', 'workHours', 'next1h')
   * @returns {Promise<void>}
   */
  async blockDomain(domain, mode) {
    // Validate domain
    const domainValidation = validateDomain(domain);
    if (!domainValidation.valid) {
      throw new Error(domainValidation.error);
    }
    
    // Validate mode
    const validModes = ['full', 'workHours', 'next1h'];
    if (!validModes.includes(mode)) {
      throw new Error('Invalid blocking mode');
    }
    
    const normalizedDomain = normalizeDomain(domain);
    if (!normalizedDomain) {
      throw new Error('Failed to normalize domain');
    }
    
    const blockedSites = await StorageService.getBlockedSites();
    const now = Date.now();
    
    const blockInfo = {
      mode: mode,
      blockedAt: now
    };
    
    // Add expiration for "next1h" mode
    if (mode === 'next1h') {
      blockInfo.expiresAt = now + (BRIEF_PAUSE_DURATION_HOURS * MS_PER_HOUR);
      // Set alarm to unblock after brief pause duration
      try {
        await safeChromeCall(
          () => chrome.alarms.create(`unblock_${normalizedDomain}`, {
            when: blockInfo.expiresAt
          }),
          'create unblock alarm'
        );
      } catch (error) {
        console.error('Failed to create unblock alarm:', error);
      }
    }
    
    blockedSites[normalizedDomain] = blockInfo;
    await StorageService.saveBlockedSites(blockedSites);
    
    // Set up periodic check for work hours
    if (mode === 'workHours') {
      try {
        await safeChromeCall(
          () => chrome.alarms.create('checkWorkHours', { periodInMinutes: WORK_HOURS_CHECK_INTERVAL_MINUTES }),
          'create work hours check alarm'
        );
      } catch (error) {
        console.error('Failed to create work hours check alarm:', error);
      }
    }
  },

  /**
   * Unblock a domain
   * @param {string} domain - Domain to unblock
   * @param {string} reason - Reason for unblocking
   * @returns {Promise<boolean>} - True if successful
   */
  async unblockDomain(domain, reason) {
    const domainValidation = validateDomain(domain);
    if (!domainValidation.valid) {
      console.error('Invalid domain for unblock:', domainValidation.error);
      return false;
    }
    
    const normalizedDomain = normalizeDomain(domain);
    if (!normalizedDomain) {
      console.error('Invalid domain for unblock:', domain);
      return false;
    }
    
    const blockedSites = await StorageService.getBlockedSites();
    if (!blockedSites[normalizedDomain]) {
      console.warn('Domain not found in blocked sites:', normalizedDomain);
      return false;
    }
    
    const blockInfo = blockedSites[normalizedDomain];
    
    // Store unblock reason in history
    if (reason && reason.trim().length > 0) {
      const reasonValidation = validateReason(reason);
      if (!reasonValidation.valid) {
        console.error('Invalid unblock reason:', reasonValidation.error);
        return false;
      }
      await this.storeUnblockReason(normalizedDomain, reason.trim(), blockInfo);
    } else {
      console.warn('No reason provided for unblocking:', normalizedDomain);
    }
    
    delete blockedSites[normalizedDomain];
    await StorageService.saveBlockedSites(blockedSites);
    
    // Clear alarm if exists
    await safeChromeCall(
      () => chrome.alarms.clear(`unblock_${normalizedDomain}`),
      'clear unblock alarm',
      true
    );
    
    return true;
  },

  /**
   * Store unblock reason in history
   * @param {string} domain - Domain that was unblocked
   * @param {string} reason - Reason for unblocking
   * @param {Object} blockInfo - Original block information
   * @returns {Promise<void>}
   */
  async storeUnblockReason(domain, reason, blockInfo) {
    const history = await StorageService.getUnblockHistory();
    
    const historyEntry = {
      domain: domain,
      reason: reason,
      timestamp: Date.now(),
      blockedAt: blockInfo.blockedAt,
      mode: blockInfo.mode,
      blockDuration: Date.now() - blockInfo.blockedAt
    };
    
    history.push(historyEntry);
    
    // Keep only last MAX_HISTORY_ENTRIES entries
    const trimmedHistory = history.slice(-MAX_HISTORY_ENTRIES);
    
    await StorageService.saveUnblockHistory(trimmedHistory);
    console.log('Unblock history stored:', historyEntry);
  },

  /**
   * Check if a domain should be blocked and redirect if needed
   * @param {string} url - URL to check
   * @param {number} tabId - Tab ID
   * @returns {Promise<Object>} - Result object with blocked status
   */
  async checkAndBlockDomain(url, tabId) {
    const domain = extractDomain(url);
    if (!domain) return { blocked: false };
    
    const normalizedDomain = normalizeDomain(domain);
    const blockedSites = await StorageService.getBlockedSites();
    
    if (!blockedSites[normalizedDomain]) {
      return { blocked: false };
    }
    
    const blockInfo = blockedSites[normalizedDomain];
    let shouldBlock = false;
    
    // Check blocking mode
    switch (blockInfo.mode) {
      case 'full':
        shouldBlock = true;
        break;
        
      case 'workHours':
        const settings = await StorageService.getSettings();
        shouldBlock = isWithinWorkHours(
          settings.workHoursStart || StorageService.DEFAULT_SETTINGS.workHoursStart,
          settings.workHoursEnd || StorageService.DEFAULT_SETTINGS.workHoursEnd
        );
        break;
        
      case 'next1h':
        const now = Date.now();
        if (blockInfo.expiresAt && now < blockInfo.expiresAt) {
          shouldBlock = true;
        } else {
          // Block expired, remove it
          await this.unblockDomain(normalizedDomain, '');
          return { blocked: false, expired: true };
        }
        break;
    }
    
    if (shouldBlock) {
      // Redirect to blocked page
      const blockedUrl = chrome.runtime.getURL('blocked.html') + '?domain=' + encodeURIComponent(normalizedDomain) + '&original=' + encodeURIComponent(url);
      await safeChromeCall(
        () => chrome.tabs.update(tabId, { url: blockedUrl }),
        `redirect tab ${tabId} to blocked page`
      );
      await this.updateIconBadge(tabId, true);
    } else {
      await this.updateIconBadge(tabId, false);
    }
    
    return {
      blocked: shouldBlock,
      domain: normalizedDomain,
      blockInfo
    };
  },

  /**
   * Update icon badge based on blocking status
   * @param {number} tabId - Tab ID
   * @param {boolean} isBlocked - Whether domain is blocked
   * @returns {Promise<void>}
   */
  async updateIconBadge(tabId, isBlocked) {
    try {
      if (isBlocked) {
        await safeChromeCall(
          () => chrome.action.setBadgeText({ text: '!', tabId: tabId }),
          `set badge text for tab ${tabId}`
        );
        await safeChromeCall(
          () => chrome.action.setBadgeBackgroundColor({ color: '#ff0000', tabId: tabId }),
          `set badge color for tab ${tabId}`
        );
      } else {
        await safeChromeCall(
          () => chrome.action.setBadgeText({ text: '', tabId: tabId }),
          `clear badge for tab ${tabId}`
        );
      }
    } catch (e) {
      console.debug('Badge update failed (tab may not exist):', e);
    }
  }
};

// Helper function for safe Chrome calls (shared with storage service)
async function safeChromeCall(apiCall, operation, defaultValue = null) {
  try {
    return await withRetry(apiCall, 3, 100);
  } catch (error) {
    console.error(`Error in ${operation}:`, error);
    return defaultValue;
  }
}

async function withRetry(fn, maxAttempts = 3, baseDelay = 100) {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts - 1) {
        throw error;
      }
      const delay = baseDelay * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

// Export for service worker
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BlockingService;
}

// Make available globally
if (typeof globalThis !== 'undefined') {
  globalThis.BlockingService = BlockingService;
}

