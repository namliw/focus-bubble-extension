/**
 * Declarative Net Request Service
 * Handles declarativeNetRequest API operations
 */

const DeclarativeNetRequestService = {
  /**
   * Get current rule IDs
   * @returns {Promise<Array<number>>} - Array of rule IDs
   */
  async getCurrentRuleIds() {
    const rules = await chrome.declarativeNetRequest.getDynamicRules();
    return rules.map(rule => rule.id);
  },

  /**
   * Update blocking rules
   * Note: We primarily use tab updates for redirects to properly pass the original URL
   * This function is kept for potential future use or as a backup mechanism
   * @returns {Promise<void>}
   */
  async updateBlockingRules() {
    // Clear all existing rules - we rely on tab updates for redirects
    const currentRuleIds = await this.getCurrentRuleIds();
    if (currentRuleIds.length > 0) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: currentRuleIds
      });
    }
    
    // The actual blocking and redirecting is handled by checkAndBlockDomain
    // which is called on tab updates. This provides better control over
    // passing the original URL to the blocked page.
  },

  /**
   * Restore blocking rules from storage on startup
   * @returns {Promise<void>}
   */
  async restoreBlockingRules() {
    await this.updateBlockingRules();
  }
};

// Export for service worker
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DeclarativeNetRequestService;
}

// Make available globally
if (typeof globalThis !== 'undefined') {
  globalThis.DeclarativeNetRequestService = DeclarativeNetRequestService;
}

