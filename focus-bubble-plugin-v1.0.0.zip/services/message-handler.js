/**
 * Message Handler Service
 * Handles all chrome.runtime.onMessage events
 */

const MessageHandler = {
  /**
   * Initialize message listeners
   */
  init() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'blockDomain') {
        BlockingService.blockDomain(request.domain, request.mode)
          .then(() => {
            sendResponse({ success: true });
          })
          .catch((error) => {
            console.error('Error blocking domain:', error);
            sendResponse({ success: false, error: error.message });
          });
        return true; // Will respond asynchronously
      }
      
      if (request.action === 'unblockDomain') {
        BlockingService.unblockDomain(request.domain, request.reason)
          .then((success) => {
            sendResponse({ success: success !== false });
          })
          .catch((error) => {
            console.error('Error unblocking domain:', error);
            sendResponse({ success: false, error: error.message });
          });
        return true;
      }
      
      if (request.action === 'getUnblockHistory') {
        StorageService.getUnblockHistory()
          .then(history => {
            sendResponse({ history });
          })
          .catch((error) => {
            console.error('Error getting unblock history:', error);
            sendResponse({ history: [] });
          });
        return true;
      }
      
      if (request.action === 'isDomainBlocked') {
        StorageService.getBlockedSites()
          .then(blockedSites => {
            const normalizedDomain = normalizeDomain(request.domain);
            sendResponse({ blocked: !!blockedSites[normalizedDomain] });
          })
          .catch((error) => {
            console.error('Error checking if domain is blocked:', error);
            sendResponse({ blocked: false });
          });
        return true;
      }
      
      if (request.action === 'getBlockedSites') {
        StorageService.getBlockedSites()
          .then(blockedSites => {
            sendResponse({ blockedSites });
          })
          .catch((error) => {
            console.error('Error getting blocked sites:', error);
            sendResponse({ blockedSites: {} });
          });
        return true;
      }
      
      if (request.action === 'getSettings') {
        StorageService.getSettings()
          .then(settings => {
            sendResponse({ settings });
          })
          .catch((error) => {
            console.error('Error getting settings:', error);
            sendResponse({ settings: {} });
          });
        return true;
      }
      
      if (request.action === 'updateSettings') {
        // Validate settings before saving
        if (request.settings.workHoursStart) {
          const startValidation = validateTimeString(request.settings.workHoursStart);
          if (!startValidation.valid) {
            sendResponse({ success: false, error: startValidation.error });
            return true;
          }
        }
        
        if (request.settings.workHoursEnd) {
          const endValidation = validateTimeString(request.settings.workHoursEnd);
          if (!endValidation.valid) {
            sendResponse({ success: false, error: endValidation.error });
            return true;
          }
        }
        
        StorageService.saveSettings(request.settings)
          .then(() => {
            // Update rules in case work hours changed
            DeclarativeNetRequestService.updateBlockingRules();
            sendResponse({ success: true });
          })
          .catch((error) => {
            console.error('Error updating settings:', error);
            sendResponse({ success: false, error: error.message });
          });
        return true;
      }
    });
  }
};

// Export for service worker
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MessageHandler;
}

// Make available globally
if (typeof globalThis !== 'undefined') {
  globalThis.MessageHandler = MessageHandler;
}

