/**
 * Storage Service
 * Handles all Chrome storage operations with error handling and retry logic
 */

// Storage keys
const STORAGE_KEY_BLOCKED_SITES = 'blockedSites';
const STORAGE_KEY_SETTINGS = 'settings';
const STORAGE_KEY_UNBLOCK_HISTORY = 'unblockHistory';

// Default settings
const DEFAULT_SETTINGS = {
  workHoursStart: '09:00',
  workHoursEnd: '17:00',
  timezone: 'local'
};

/**
 * Retry a function with exponential backoff
 */
async function withRetry(fn, maxAttempts = 3, baseDelay = 100) {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts - 1) {
        throw error;
      }
      const delay = baseDelay * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

/**
 * Safely execute Chrome API call with error handling
 */
async function safeChromeCall(apiCall, operation, defaultValue = null) {
  try {
    return await withRetry(apiCall, 3, 100);
  } catch (error) {
    console.error(`Error in ${operation}:`, error);
    return defaultValue;
  }
}

const StorageService = {
  STORAGE_KEY_BLOCKED_SITES,
  STORAGE_KEY_SETTINGS,
  STORAGE_KEY_UNBLOCK_HISTORY,
  DEFAULT_SETTINGS,

  /**
   * Get all blocked sites
   * @returns {Promise<Object>} - Object mapping domains to block info
   */
  async getBlockedSites() {
    return await safeChromeCall(
      () => chrome.storage.local.get(STORAGE_KEY_BLOCKED_SITES),
      'getBlockedSites',
      { [STORAGE_KEY_BLOCKED_SITES]: {} }
    ).then(result => result[STORAGE_KEY_BLOCKED_SITES] || {});
  },

  /**
   * Save blocked sites
   * @param {Object} blockedSites - Blocked sites object
   * @returns {Promise<void>}
   */
  async saveBlockedSites(blockedSites) {
    return await safeChromeCall(
      () => chrome.storage.local.set({ [STORAGE_KEY_BLOCKED_SITES]: blockedSites }),
      'saveBlockedSites'
    );
  },

  /**
   * Get settings
   * @returns {Promise<Object>} - Settings object
   */
  async getSettings() {
    return await safeChromeCall(
      () => chrome.storage.local.get(STORAGE_KEY_SETTINGS),
      'getSettings',
      { [STORAGE_KEY_SETTINGS]: DEFAULT_SETTINGS }
    ).then(result => result[STORAGE_KEY_SETTINGS] || DEFAULT_SETTINGS);
  },

  /**
   * Save settings
   * @param {Object} settings - Settings object
   * @returns {Promise<void>}
   */
  async saveSettings(settings) {
    return await safeChromeCall(
      () => chrome.storage.local.set({ [STORAGE_KEY_SETTINGS]: settings }),
      'saveSettings'
    );
  },

  /**
   * Get unblock history
   * @returns {Promise<Array>} - Array of history entries
   */
  async getUnblockHistory() {
    return await safeChromeCall(
      () => chrome.storage.local.get(STORAGE_KEY_UNBLOCK_HISTORY),
      'getUnblockHistory',
      { [STORAGE_KEY_UNBLOCK_HISTORY]: [] }
    ).then(result => result[STORAGE_KEY_UNBLOCK_HISTORY] || []);
  },

  /**
   * Save unblock history
   * @param {Array} history - History array
   * @returns {Promise<void>}
   */
  async saveUnblockHistory(history) {
    return await safeChromeCall(
      () => chrome.storage.local.set({ [STORAGE_KEY_UNBLOCK_HISTORY]: history }),
      'saveUnblockHistory'
    );
  },

  /**
   * Initialize default settings if they don't exist
   * @returns {Promise<void>}
   */
  async initializeSettings() {
    const result = await safeChromeCall(
      () => chrome.storage.local.get(STORAGE_KEY_SETTINGS),
      'initializeSettings',
      {}
    );
    
    if (!result[STORAGE_KEY_SETTINGS]) {
      await this.saveSettings(DEFAULT_SETTINGS);
    }
  }
};

// Export for service worker
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StorageService;
}

// Make available globally
if (typeof globalThis !== 'undefined') {
  globalThis.StorageService = StorageService;
}

