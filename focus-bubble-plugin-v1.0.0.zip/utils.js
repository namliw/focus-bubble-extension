// Utility functions for domain extraction, normalization, and validation
// This is the single source of truth for all shared utility functions

// ============================================
// Constants
// ============================================

// Domain validation
const RFC_1035_MAX_DOMAIN_LENGTH = 253;
const RULE_ID_MODULO = 1000000;

// Text validation
const MAX_REASON_LENGTH = 1000;

// Storage limits
const MAX_HISTORY_ENTRIES = 100;

// Time constants (milliseconds)
const MS_PER_SECOND = 1000;
const MS_PER_MINUTE = 60 * MS_PER_SECOND; // 60000
const MS_PER_HOUR = 60 * MS_PER_MINUTE;   // 3600000
const MS_PER_DAY = 24 * MS_PER_HOUR;      // 86400000

// Time conversion
const MINUTES_PER_HOUR = 60;
const HOURS_PER_DAY = 24;
const DAYS_PER_WEEK = 7;

// Alarm/check intervals
const WORK_HOURS_CHECK_INTERVAL_MINUTES = 1;
const BRIEF_PAUSE_DURATION_HOURS = 1;

// ============================================
// Domain Utilities
// ============================================

/**
 * Extract domain from a URL
 * @param {string} url - The URL to extract domain from
 * @returns {string|null} - The normalized domain or null if invalid
 */
function extractDomain(url) {
  try {
    const urlObj = new URL(url);
    let hostname = urlObj.hostname;
    
    // Remove www. prefix if present
    if (hostname.startsWith('www.')) {
      hostname = hostname.substring(4);
    }
    
    return hostname;
  } catch (e) {
    return null;
  }
}

/**
 * Normalize domain (remove www, convert to lowercase)
 * @param {string} domain - The domain to normalize
 * @returns {string} - Normalized domain
 */
function normalizeDomain(domain) {
  if (!domain) return '';
  let normalized = domain.toLowerCase().trim();
  if (normalized.startsWith('www.')) {
    normalized = normalized.substring(4);
  }
  return normalized;
}

/**
 * Validate domain format and length
 * @param {string} domain - The domain to validate
 * @returns {{valid: boolean, error?: string}} - Validation result
 */
function validateDomain(domain) {
  if (!domain || typeof domain !== 'string') {
    return { valid: false, error: 'Domain is required' };
  }
  
  // RFC 1035 limit for domain names
  if (domain.length > RFC_1035_MAX_DOMAIN_LENGTH) {
    return { valid: false, error: 'Domain name too long (max 253 characters)' };
  }
  
  // Basic domain format validation (alphanumeric, dots, hyphens)
  if (!/^[a-zA-Z0-9.-]+$/.test(domain)) {
    return { valid: false, error: 'Invalid domain format' };
  }
  
  return { valid: true };
}

// ============================================
// Time Utilities
// ============================================

/**
 * Validate time string format (HH:MM)
 * @param {string} timeStr - Time string to validate
 * @returns {{valid: boolean, error?: string, hours?: number, minutes?: number}} - Validation result
 */
function validateTimeString(timeStr) {
  if (!timeStr || typeof timeStr !== 'string') {
    return { valid: false, error: 'Time is required' };
  }
  
  // Validate format HH:MM
  if (!/^\d{1,2}:\d{2}$/.test(timeStr)) {
    return { valid: false, error: 'Invalid time format (use HH:MM)' };
  }
  
  const [hours, minutes] = timeStr.split(':').map(Number);
  
  if (isNaN(hours) || isNaN(minutes)) {
    return { valid: false, error: 'Invalid time values' };
  }
  
  if (hours < 0 || hours > 23) {
    return { valid: false, error: 'Hours must be between 0 and 23' };
  }
  
  if (minutes < 0 || minutes > 59) {
    return { valid: false, error: 'Minutes must be between 0 and 59' };
  }
  
  return { valid: true, hours, minutes };
}

/**
 * Check if current time is within work hours
 * @param {string} startTime - Start time in HH:MM format (24-hour)
 * @param {string} endTime - End time in HH:MM format (24-hour)
 * @returns {boolean} - True if current time is within work hours
 */
function isWithinWorkHours(startTime, endTime) {
  const now = new Date();
  const currentHours = now.getHours();
  const currentMinutes = now.getMinutes();
  const currentTotalMinutes = currentHours * MINUTES_PER_HOUR + currentMinutes;
  
  // Validate time strings
  const startValidation = validateTimeString(startTime);
  const endValidation = validateTimeString(endTime);
  
  if (!startValidation.valid || !endValidation.valid) {
    console.error('Invalid work hours:', startValidation.error || endValidation.error);
    return false; // Fail safe - don't block if times are invalid
  }
  
  const startTotalMinutes = startValidation.hours * MINUTES_PER_HOUR + startValidation.minutes;
  const endTotalMinutes = endValidation.hours * MINUTES_PER_HOUR + endValidation.minutes;
  
  if (startTotalMinutes <= endTotalMinutes) {
    return currentTotalMinutes >= startTotalMinutes && currentTotalMinutes < endTotalMinutes;
  } else {
    return currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes;
  }
}

// ============================================
// Validation Utilities
// ============================================

/**
 * Validate unblock reason
 * @param {string} reason - The reason to validate
 * @returns {{valid: boolean, error?: string}} - Validation result
 */
function validateReason(reason) {
  if (!reason || typeof reason !== 'string') {
    return { valid: false, error: 'Reason is required' };
  }
  
  const trimmed = reason.trim();
  if (trimmed.length === 0) {
    return { valid: false, error: 'Reason cannot be empty' };
  }
  
  if (trimmed.length > MAX_REASON_LENGTH) {
    return { valid: false, error: 'Reason too long (max 1000 characters)' };
  }
  
  return { valid: true };
}

/**
 * Generate a unique rule ID from domain
 * @param {string} domain - The domain
 * @returns {number} - Rule ID
 */
function generateRuleId(domain) {
  // Simple hash function to generate consistent rule IDs
  let hash = 0;
  for (let i = 0; i < domain.length; i++) {
    const char = domain.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash) % RULE_ID_MODULO;
}

// ============================================
// Formatting Utilities
// ============================================

/**
 * Format timestamp as relative time or date
 * @param {number} timestamp - Unix timestamp in milliseconds
 * @returns {string} - Formatted time string
 */
function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / MS_PER_MINUTE);
  const diffHours = Math.floor(diffMins / MINUTES_PER_HOUR);
  const diffDays = Math.floor(diffHours / HOURS_PER_DAY);
  
  if (diffMins < 1) return 'Just now';
  if (diffMins < MINUTES_PER_HOUR) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  if (diffHours < HOURS_PER_DAY) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < DAYS_PER_WEEK) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  
  // For older entries, show date
  return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

/**
 * Format duration in milliseconds to human-readable string
 * @param {number} ms - Duration in milliseconds
 * @returns {string} - Formatted duration string
 */
function formatDuration(ms) {
  const minutes = Math.floor(ms / MS_PER_MINUTE);
  const hours = Math.floor(minutes / MINUTES_PER_HOUR);
  const days = Math.floor(hours / HOURS_PER_DAY);
  
  if (days > 0) {
    return `${days} day${days > 1 ? 's' : ''} ${hours % HOURS_PER_DAY}h`;
  }
  if (hours > 0) {
    return `${hours}h ${minutes % MINUTES_PER_HOUR}m`;
  }
  return `${minutes}m`;
}

/**
 * Format time remaining until expiration
 * @param {number} expiresAt - Expiration timestamp in milliseconds
 * @returns {string} - Formatted time remaining string
 */
function formatTimeRemaining(expiresAt) {
  const now = Date.now();
  const remaining = expiresAt - now;
  if (remaining <= 0) return 'Shield removed';
  
  const minutes = Math.floor(remaining / MS_PER_MINUTE);
  const hours = Math.floor(minutes / MINUTES_PER_HOUR);
  
  if (hours > 0) {
    return `${hours}h ${minutes % MINUTES_PER_HOUR}m remaining`;
  }
  return `${minutes}m remaining`;
}

/**
 * Format blocking mode for display
 * @param {string} mode - Blocking mode ('full', 'workHours', 'next1h')
 * @param {Object} blockInfo - Block information object
 * @returns {string} - Formatted mode string
 */
function formatBlockingMode(mode, blockInfo) {
  switch (mode) {
    case 'full':
      return 'Deep Focus';
    case 'workHours':
      return 'Work Hours';
    case 'next1h':
      if (blockInfo.expiresAt) {
        const now = Date.now();
        const remaining = blockInfo.expiresAt - now;
        if (remaining > 0) {
          const minutes = Math.floor(remaining / MS_PER_MINUTE);
          const hours = Math.floor(minutes / MINUTES_PER_HOUR);
          if (hours > 0) {
            return `Brief Pause (${hours}h ${minutes % MINUTES_PER_HOUR}m remaining)`;
          }
          return `Brief Pause (${minutes}m remaining)`;
        }
      }
      return 'Brief Pause';
    default:
      return mode;
  }
}

// ============================================
// Exports (for ES modules or global scope)
// ============================================

// Export for use in Chrome extension context
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    extractDomain,
    normalizeDomain,
    validateDomain,
    validateTimeString,
    isWithinWorkHours,
    validateReason,
    generateRuleId,
    formatTimestamp,
    formatDuration,
    formatTimeRemaining,
    formatBlockingMode,
    // Constants
    RFC_1035_MAX_DOMAIN_LENGTH,
    MAX_REASON_LENGTH,
    MAX_HISTORY_ENTRIES,
    RULE_ID_MODULO,
    MS_PER_SECOND,
    MS_PER_MINUTE,
    MS_PER_HOUR,
    MS_PER_DAY,
    MINUTES_PER_HOUR,
    HOURS_PER_DAY,
    DAYS_PER_WEEK,
    WORK_HOURS_CHECK_INTERVAL_MINUTES,
    BRIEF_PAUSE_DURATION_HOURS
  };
}

// Also make available globally for Chrome extension scripts
if (typeof window !== 'undefined' || typeof globalThis !== 'undefined') {
  const global = typeof window !== 'undefined' ? window : globalThis;
  global.extractDomain = extractDomain;
  global.normalizeDomain = normalizeDomain;
  global.validateDomain = validateDomain;
  global.validateTimeString = validateTimeString;
  global.isWithinWorkHours = isWithinWorkHours;
  global.validateReason = validateReason;
  global.generateRuleId = generateRuleId;
  global.formatTimestamp = formatTimestamp;
  global.formatDuration = formatDuration;
  global.formatTimeRemaining = formatTimeRemaining;
  global.formatBlockingMode = formatBlockingMode;
  // Constants
  global.RFC_1035_MAX_DOMAIN_LENGTH = RFC_1035_MAX_DOMAIN_LENGTH;
  global.MAX_REASON_LENGTH = MAX_REASON_LENGTH;
  global.MAX_HISTORY_ENTRIES = MAX_HISTORY_ENTRIES;
  global.RULE_ID_MODULO = RULE_ID_MODULO;
  global.MS_PER_SECOND = MS_PER_SECOND;
  global.MS_PER_MINUTE = MS_PER_MINUTE;
  global.MS_PER_HOUR = MS_PER_HOUR;
  global.MS_PER_DAY = MS_PER_DAY;
  global.MINUTES_PER_HOUR = MINUTES_PER_HOUR;
  global.HOURS_PER_DAY = HOURS_PER_DAY;
  global.DAYS_PER_WEEK = DAYS_PER_WEEK;
  global.WORK_HOURS_CHECK_INTERVAL_MINUTES = WORK_HOURS_CHECK_INTERVAL_MINUTES;
  global.BRIEF_PAUSE_DURATION_HOURS = BRIEF_PAUSE_DURATION_HOURS;
}
