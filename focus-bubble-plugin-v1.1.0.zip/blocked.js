// Blocked page script

// ============================================
// Water Ripple Interactive Background
// ============================================

class Particle {
  constructor(canvasWidth, canvasHeight) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.reset(true);
  }

  reset(randomPosition = false) {
    if (randomPosition) {
      this.x = Math.random() * this.canvasWidth;
      this.y = Math.random() * this.canvasHeight;
    }
    this.baseX = this.x;
    this.baseY = this.y;
    this.size = Math.random() * 3 + 1;
    this.baseOpacity = Math.random() * 0.4 + 0.1;
    this.opacity = this.baseOpacity;
    this.pulsePhase = Math.random() * Math.PI * 2;
    this.pulseSpeed = Math.random() * 0.02 + 0.01;
    this.driftX = (Math.random() - 0.5) * 0.3;
    this.driftY = (Math.random() - 0.5) * 0.2 - 0.1; // Slight upward drift
    this.vx = 0;
    this.vy = 0;
    this.pushed = false;
  }

  update() {
    // Natural drift movement
    this.baseX += this.driftX;
    this.baseY += this.driftY;
    
    // Wrap around screen edges
    if (this.baseX < -10) this.baseX = this.canvasWidth + 10;
    if (this.baseX > this.canvasWidth + 10) this.baseX = -10;
    if (this.baseY < -10) this.baseY = this.canvasHeight + 10;
    if (this.baseY > this.canvasHeight + 10) this.baseY = -10;
    
    // Apply push velocity with friction
    this.vx *= 0.95;
    this.vy *= 0.95;
    this.x = this.baseX + this.vx;
    this.y = this.baseY + this.vy;
    
    // Return to base position gradually
    if (Math.abs(this.vx) < 0.1 && Math.abs(this.vy) < 0.1) {
      this.vx = 0;
      this.vy = 0;
      this.pushed = false;
    }
    
    // Gentle pulse animation
    this.pulsePhase += this.pulseSpeed;
    const pulseFactor = 0.3 * Math.sin(this.pulsePhase);
    this.opacity = this.baseOpacity * (1 + pulseFactor);
    
    // Brighten when pushed
    if (this.pushed) {
      this.opacity = Math.min(0.9, this.opacity + 0.3);
    }
  }

  reactToRipple(ripple) {
    const dx = this.x - ripple.x;
    const dy = this.y - ripple.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Check if ripple edge is passing through particle
    const rippleEdge = ripple.radius;
    const threshold = 30;
    
    if (distance > rippleEdge - threshold && distance < rippleEdge + threshold) {
      // Normalize direction away from ripple center
      const nx = dx / distance;
      const ny = dy / distance;
      
      // Push strength based on ripple opacity (stronger when ripple is fresh)
      const strength = ripple.opacity * 8;
      
      this.vx += nx * strength;
      this.vy += ny * strength;
      this.pushed = true;
    }
  }

  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(56, 189, 248, ${this.opacity})`;
    ctx.fill();
    
    // Add glow for larger particles
    if (this.size > 2) {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size * 2, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(56, 189, 248, ${this.opacity * 0.2})`;
      ctx.fill();
    }
  }
}

class Ripple {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 0;
    this.maxRadius = 350;
    this.opacity = 1.0;
    this.rings = 3;
    this.speed = 2.5;
    this.startTime = performance.now();
  }

  update() {
    this.radius += this.speed;
    // Fade out as ripple expands - slower fade
    const fadeStart = 0.7; // Start fading at 70% of max radius
    if (this.radius < this.maxRadius * fadeStart) {
      this.opacity = 0.9;
    } else {
      const fadeProgress = (this.radius - this.maxRadius * fadeStart) / (this.maxRadius * (1 - fadeStart));
      this.opacity = 0.9 * (1 - fadeProgress);
    }
    return this.radius < this.maxRadius;
  }

  draw(ctx) {
    if (this.opacity <= 0) return;
    
    const ringSpacing = 30;
    
    for (let i = 0; i < this.rings; i++) {
      const ringRadius = this.radius - (i * ringSpacing);
      if (ringRadius <= 0) continue;
      
      // Each ring fades slightly differently
      const ringOpacity = this.opacity * (1 - i * 0.25);
      if (ringOpacity <= 0) continue;
      
      ctx.save();
      
      // Draw outer glow
      ctx.beginPath();
      ctx.arc(this.x, this.y, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(56, 189, 248, ${ringOpacity * 0.4})`;
      ctx.lineWidth = 12;
      ctx.stroke();
      
      // Draw middle glow
      ctx.beginPath();
      ctx.arc(this.x, this.y, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(56, 189, 248, ${ringOpacity * 0.6})`;
      ctx.lineWidth = 6;
      ctx.stroke();
      
      // Draw sharp center ring with glow
      ctx.beginPath();
      ctx.arc(this.x, this.y, ringRadius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(56, 189, 248, ${ringOpacity})`;
      ctx.lineWidth = 2;
      ctx.shadowColor = `rgba(56, 189, 248, ${ringOpacity})`;
      ctx.shadowBlur = 20;
      ctx.stroke();
      
      ctx.restore();
    }
  }
}

class RippleEngine {
  constructor(canvas) {
    this.canvas = canvas;
    if (!this.canvas) {
      console.error('Canvas element not provided to RippleEngine');
      return;
    }
    
    this.ctx = canvas.getContext('2d');
    if (!this.ctx) {
      console.error('Could not get 2d context from canvas');
      return;
    }
    
    this.ripples = [];
    this.particles = [];
    this.maxRipples = 10; // Reduced from 15 for better visibility
    this.particleCount = 160; // Doubled from 80 to 160
    this.isAnimating = false;
    this.lastRippleTime = 0;
    this.rippleThrottle = 200; // ms between ripples on mouse move
    this.minRippleDistance = 80; // Minimum pixels between ripples (distance-based throttling)
    this.lastRippleX = null;
    this.lastRippleY = null;
    this.time = 0; // For animated gradient
    this.animationFrameId = null;
    
    this.resize();
    this.initParticles();
    this.bindEvents();
    
    // Start particle animation (always running for ambient effect)
    this.startAmbientAnimation();
  }

  resize() {
    const width = window.innerWidth || document.documentElement.clientWidth || 800;
    const height = window.innerHeight || document.documentElement.clientHeight || 600;
    
    this.canvas.width = width;
    this.canvas.height = height;
    
    // Reposition particles on resize
    this.particles.forEach(p => {
      p.canvasWidth = this.canvas.width;
      p.canvasHeight = this.canvas.height;
    });
  }

  initParticles() {
    this.particles = [];
    for (let i = 0; i < this.particleCount; i++) {
      this.particles.push(new Particle(this.canvas.width, this.canvas.height));
    }
  }

  bindEvents() {
    // Resize handler
    window.addEventListener('resize', () => this.resize());
    
    // Mouse move creates ripples (throttling handled in createRipple)
    this.canvas.addEventListener('mousemove', (e) => {
      e.preventDefault();
      this.createRipple(e.clientX, e.clientY);
    });
    
    // Touch move support
    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        this.createRipple(touch.clientX, touch.clientY);
      }
    });
    
    // Also listen on document for better coverage
    document.addEventListener('mousemove', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      if (e.clientX >= rect.left && e.clientX <= rect.right &&
          e.clientY >= rect.top && e.clientY <= rect.bottom) {
        this.createRipple(e.clientX, e.clientY);
      }
    });
    
    // Pause animation when tab is hidden to save resources
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.stop();
      } else {
        this.startAmbientAnimation();
      }
    });
  }

  createRipple(x, y) {
    const now = performance.now();
    
    // Time-based throttle
    if (now - this.lastRippleTime < this.rippleThrottle) {
      return; // Too soon since last ripple
    }
    
    // Distance-based throttle
    if (this.lastRippleX !== null && this.lastRippleY !== null) {
      const dx = x - this.lastRippleX;
      const dy = y - this.lastRippleY;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < this.minRippleDistance) {
        return; // Too close to last ripple, skip
      }
    }
    
    // Remove oldest ripple if at max
    if (this.ripples.length >= this.maxRipples) {
      this.ripples.shift();
    }
    
    this.ripples.push(new Ripple(x, y));
    this.lastRippleTime = now;
    this.lastRippleX = x;
    this.lastRippleY = y;
  }

  drawGradient() {
    // Animated ocean gradient with shifting light
    // Create gradient from top to bottom
    const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
    
    // Base colors from Deep Ocean theme
    const baseStart = { r: 15, g: 23, b: 42 }; // #0F172A
    const baseEnd = { r: 30, g: 41, b: 59 };   // #1E293B
    
    // Animate color shifts with sine waves for smooth transitions
    // Shift hue slightly to simulate light filtering through water
    const timeShift = Math.sin(this.time * 0.0005) * 0.3; // Slow, subtle shift
    const depthShift = Math.sin(this.time * 0.0003) * 0.2; // Different frequency for depth
    
    // Top color - lighter, more blue (surface light) - brighter
    const topR = Math.max(0, Math.min(255, baseStart.r + Math.sin(this.time * 0.0005) * 5 + timeShift * 10 + 8));
    const topG = Math.max(0, Math.min(255, baseStart.g + Math.sin(this.time * 0.0004) * 8 + timeShift * 15 + 12));
    const topB = Math.max(0, Math.min(255, baseStart.b + Math.sin(this.time * 0.0006) * 10 + timeShift * 20 + 15));
    
    // Middle color - transition
    const midR = Math.max(0, Math.min(255, (baseStart.r + baseEnd.r) / 2 + depthShift * 5));
    const midG = Math.max(0, Math.min(255, (baseStart.g + baseEnd.g) / 2 + depthShift * 8));
    const midB = Math.max(0, Math.min(255, (baseStart.b + baseEnd.b) / 2 + depthShift * 12));
    
    // Bottom color - deeper, darker
    const bottomR = Math.max(0, Math.min(255, baseEnd.r + Math.sin(this.time * 0.0004) * 3));
    const bottomG = Math.max(0, Math.min(255, baseEnd.g + Math.sin(this.time * 0.0005) * 5));
    const bottomB = Math.max(0, Math.min(255, baseEnd.b + Math.sin(this.time * 0.0006) * 7));
    
    // Create gradient stops
    gradient.addColorStop(0, `rgb(${Math.floor(topR)}, ${Math.floor(topG)}, ${Math.floor(topB)})`);
    gradient.addColorStop(0.5, `rgb(${Math.floor(midR)}, ${Math.floor(midG)}, ${Math.floor(midB)})`);
    gradient.addColorStop(1, `rgb(${Math.floor(bottomR)}, ${Math.floor(bottomG)}, ${Math.floor(bottomB)})`);
    
    // Fill canvas with gradient
    this.ctx.fillStyle = gradient;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }

  animate() {
    if (!this.isAnimating) return;
    
    // Increment time for gradient animation
    this.time += 16; // ~60fps (16ms per frame)
    
    // Draw animated ocean gradient background first
    this.drawGradient();
    
    // Update and draw particles
    this.particles.forEach(particle => {
      // React to all active ripples
      this.ripples.forEach(ripple => {
        particle.reactToRipple(ripple);
      });
      particle.update();
      particle.draw(this.ctx);
    });
    
    // Update and draw ripples
    this.ripples = this.ripples.filter(ripple => {
      const alive = ripple.update();
      if (alive) {
        ripple.draw(this.ctx);
      }
      return alive;
    });
    
    // Continue animation (always running for particles)
    this.animationFrameId = requestAnimationFrame(() => this.animate());
  }

  startAmbientAnimation() {
    if (!this.isAnimating) {
      this.isAnimating = true;
      this.animate();
    }
  }

  stop() {
    if (this.isAnimating) {
      this.isAnimating = false;
      if (this.animationFrameId) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
      }
    }
  }
}

// Initialize ripple engine when DOM is ready
function initRippleEngine() {
  const canvas = document.getElementById('rippleCanvas');
  if (!canvas) {
    console.error('Canvas element not found for ripple engine');
    return;
  }
  
  // Ensure canvas is visible and has proper styling
  if (canvas.style.display === 'none') {
    canvas.style.display = 'block';
  }
  
  try {
    window.rippleEngine = new RippleEngine(canvas);
    console.log('Ripple engine initialized successfully');
  } catch (error) {
    console.error('Error initializing ripple engine:', error);
  }
}

// ============================================
// Blocked Page Logic
// ============================================

// Get URL parameters
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    domain: params.get('domain'),
    original: params.get('original')
  };
}

// Unblock domain with reason
async function unblockDomain(domain, reason) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'unblockDomain', domain: domain, reason: reason },
      (response) => {
        resolve(response?.success || false);
      }
    );
  });
}

// Get blocked sites info
async function getBlockedSites() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getBlockedSites' },
      (response) => {
        resolve(response?.blockedSites || {});
      }
    );
  });
}

// Get settings
async function getSettings() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'getSettings' },
      (response) => {
        resolve(response?.settings || {});
      }
    );
  });
}

// Note: formatTimeRemaining, validateTimeString, and isWithinWorkHours 
// are imported from utils.js

// Initialize blocked page
async function initBlockedPage() {
  const params = getUrlParams();
  const domain = params.domain;
  const originalUrl = params.original;
  
  if (!domain) {
    document.getElementById('blockedDomain').textContent = 'Unknown space';
    return;
  }
  
  document.getElementById('blockedDomain').textContent = domain;
  
  // Get protection info
  const blockedSites = await getBlockedSites();
  const blockInfo = blockedSites[domain];
  
  if (blockInfo) {
    const blockInfoDiv = document.getElementById('blockInfo');
    const infoText = document.getElementById('infoText');
    
    let infoMessage = '';
    switch (blockInfo.mode) {
      case 'full':
        infoMessage = 'Focus mode: Deep Focus';
        break;
      case 'workHours':
        const settings = await getSettings();
        const withinHours = isWithinWorkHours(
          settings.workHoursStart || '09:00',
          settings.workHoursEnd || '17:00'
        );
        infoMessage = `Focus mode: Work Hours (${settings.workHoursStart || '09:00'} - ${settings.workHoursEnd || '17:00'})`;
        if (!withinHours) {
          infoMessage += ' - Currently outside work hours, but shield remains active';
        }
        break;
      case 'next1h':
        if (blockInfo.expiresAt) {
          const remaining = formatTimeRemaining(blockInfo.expiresAt);
          infoMessage = `Focus mode: Brief Pause - ${remaining}`;
        } else {
          infoMessage = 'Focus mode: Brief Pause';
        }
        break;
    }
    
    infoText.textContent = infoMessage;
    blockInfoDiv.style.display = 'block';
  }
  
  // Set up reason textarea and unblock button
  const reasonTextarea = document.getElementById('unblockReason');
  const unblockButton = document.getElementById('unblockButton');
  
  // Enable/disable unblock button based on reason input
  reasonTextarea.addEventListener('input', () => {
    const reason = reasonTextarea.value.trim();
    unblockButton.disabled = reason.length === 0;
  });
  
  // Set up unblock button
  unblockButton.addEventListener('click', async () => {
    const reason = reasonTextarea.value.trim();
    
    if (reason.length === 0) {
      return; // Should not happen due to disabled state, but safety check
    }
    
    // Validate reason length to prevent storage bloat
    if (reason.length > MAX_REASON_LENGTH) {
      alert(`Reason is too long (maximum ${MAX_REASON_LENGTH} characters)`);
      return;
    }
    
    const success = await unblockDomain(domain, reason);
    
    if (success && originalUrl) {
      // Validate URL before redirecting to prevent open redirect attacks
      try {
        const url = new URL(originalUrl);
        // Only allow http/https protocols to prevent javascript:, data:, etc.
        if (url.protocol === 'http:' || url.protocol === 'https:') {
          window.location.href = originalUrl;
        } else {
          console.warn('Blocked redirect to non-HTTP(S) URL:', url.protocol);
          window.location.href = 'https://www.google.com';
        }
      } catch (e) {
        console.error('Invalid URL format:', originalUrl, e);
        window.location.href = 'https://www.google.com';
      }
    } else if (success) {
      // If no original URL, redirect to a safe page
      window.location.href = 'https://www.google.com';
    }
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    initRippleEngine();
    initBlockedPage();
  });
} else {
  initRippleEngine();
  initBlockedPage();
}

